<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PaymentGateways extends Model
{
    protected $guarded = array();
    public $timestamps = false;
}
